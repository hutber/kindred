create function trigger_xevent_last_update() returns trigger
LANGUAGE plpgsql
AS $$
begin
  case TG_OP
    when 'INSERT' then
      update xevent set last_update=now() where xevent.id=new.xevent_id and xevent.last_update != now();
      return new;
    when 'UPDATE' then
      update xevent set last_update=now() where xevent.id=new.xevent_id and xevent.last_update != now();
      return new;
  end case;
  return null;
end;
$$;
