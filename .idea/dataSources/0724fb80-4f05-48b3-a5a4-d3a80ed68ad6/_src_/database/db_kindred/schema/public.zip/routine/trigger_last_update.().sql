create function trigger_last_update() returns trigger
LANGUAGE plpgsql
AS $$
begin
  new.last_update = now();
  return new;
end;
$$;
