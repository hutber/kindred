create function extract_etag(p_time timestamp with time zone) returns bigint
LANGUAGE plpgsql
AS $$
begin
    return (extract(epoch from p_time at time zone 'UTC')*1000000)::bigint;
end;
$$;
